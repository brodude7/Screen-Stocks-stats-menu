using UnityEngine;

namespace ScreenStocksStats
{
    public sealed partial class Plugin
    {
        private Texture2D checkboxOn, checkboxOff;

        private bool SettingsCheckbox(bool value, string label)
        {
            var textStyle = new GUIStyle(GUI.skin.label) { wordWrap = true, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleLeft };
            float labelWidth = Mathf.Max(80, window.width - 140);
            float height = Mathf.Max(30, textStyle.CalcHeight(new GUIContent(label), labelWidth) + 4);
            Rect row = GUILayoutUtility.GetRect(0, height, GUILayout.ExpandWidth(true));
            bool result = GUI.Toggle(row, value, GUIContent.none, GUIStyle.none);
            if (Event.current.type == EventType.Repaint)
            {
                GUI.DrawTexture(new Rect(row.x + 2, row.y + (height - 22) / 2, 22, 22), result ? checkboxOn : checkboxOff);
                GUI.Label(new Rect(row.x + 32, row.y, Mathf.Max(40, row.width - 78), height), label, textStyle);
                var stateStyle = new GUIStyle(textStyle) { alignment = TextAnchor.MiddleRight, fontSize = 12, wordWrap = false };
                GUI.Label(new Rect(row.xMax - 40, row.y, 38, height), result ? "ON" : "OFF", stateStyle);
            }
            return result;
        }

        private Texture2D CheckboxTexture(Color surface, bool selected)
        {
            const int size = 64;
            Color border = themeText;
            Color fill = selected ? Color.Lerp(surface, themeText, 0.85f) : surface;
            Color mark = themeText == Color.white ? Color.black : Color.white;
            var pixels = new Color[size * size];
            for (int y = 0; y < size; y++)
                for (int x = 0; x < size; x++)
                {
                    Vector2 point = new Vector2(x + 0.5f, y + 0.5f);
                    if (!InsideRounded(point, 1, 63, 13)) continue;
                    Color ink = InsideRounded(point, 6, 58, 9) ? fill : border;
                    if (selected && (SegmentDistance(point, new Vector2(17, 32), new Vector2(28, 21)) <= 3.5f || SegmentDistance(point, new Vector2(28, 21), new Vector2(48, 44)) <= 3.5f)) ink = mark;
                    pixels[y * size + x] = ink;
                }
            var texture = new Texture2D(size, size, TextureFormat.RGBA32, false);
            texture.hideFlags = HideFlags.HideAndDontSave;
            texture.wrapMode = TextureWrapMode.Clamp;
            texture.filterMode = FilterMode.Bilinear;
            texture.SetPixels(pixels);
            texture.Apply(false, true);
            themeTextures.Add(texture);
            return texture;
        }

        private static bool InsideRounded(Vector2 p, float min, float max, float radius)
        {
            Vector2 center = new Vector2(Mathf.Clamp(p.x, min + radius, max - radius), Mathf.Clamp(p.y, min + radius, max - radius));
            return (p - center).sqrMagnitude <= radius * radius;
        }

        private static float SegmentDistance(Vector2 point, Vector2 a, Vector2 b)
        {
            Vector2 delta = b - a;
            float t = Mathf.Clamp01(Vector2.Dot(point - a, delta) / delta.sqrMagnitude);
            return (point - (a + t * delta)).magnitude;
        }
    }
}
