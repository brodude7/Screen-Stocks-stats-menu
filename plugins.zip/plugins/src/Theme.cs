using System.Collections.Generic;
using UnityEngine;

namespace ScreenStocksStats
{
    public sealed partial class Plugin
    {
        private GUISkin themedSkin;
        private string appliedCustomTheme;
        private BGSkinSO activeTheme;
        private readonly List<Texture2D> themeTextures = new List<Texture2D>();
        private Color themeText = Color.white, themeMuted = Color.gray;
        private Color chartBackground = new Color(0.065f, 0.08f, 0.12f, 1f);
        private Color chartGrid = new Color(0.2f, 0.24f, 0.3f);
        private Color themeAccent = new Color(0.35f, 0.9f, 0.77f);

        private void OnGUI()
        {
            GUISkin original = GUI.skin;
            Color background = GUI.backgroundColor;
            try
            {
                var manager = BGSkinManager.Instance;
                var selected = manager == null || !followTheme.Value ? null : manager.GetEquippedSkin();
                string customKey = followTheme.Value ? "game" : primaryHex.Value + ":" + secondaryHex.Value;
                if (themedSkin == null || selected != activeTheme || appliedCustomTheme != customKey)
                {
                    BuildTheme(original, selected);
                    appliedCustomTheme = customKey;
                }
                GUI.skin = themedSkin;
                GUI.backgroundColor = Color.white;
                DrawThemedGUI();
            }
            finally { GUI.skin = original; GUI.backgroundColor = background; }
        }

        private void BuildTheme(GUISkin original, BGSkinSO selected)
        {
            ReleaseTheme();
            activeTheme = selected;
            themedSkin = Instantiate(original);
            themedSkin.hideFlags = HideFlags.HideAndDontSave;
            Color surface = selected == null ? new Color(0.16f, 0.19f, 0.27f) : selected.UsesOSFrame ? selected.OSFrameColor : selected.uiImageColor;
            if (!followTheme.Value && ColorUtility.TryParseHtmlString(primaryHex.Value, out var customPrimary)) surface = customPrimary;
            Color secondary = surface;
            if (!followTheme.Value && ColorUtility.TryParseHtmlString(secondaryHex.Value, out var customSecondary)) secondary = customSecondary;
            secondary.a = 1;
            surface = new Color(Mathf.Clamp01(surface.r), Mathf.Clamp01(surface.g), Mathf.Clamp01(surface.b), 1);
            float luminance = 0.2126f * Mathf.GammaToLinearSpace(surface.r) + 0.7152f * Mathf.GammaToLinearSpace(surface.g) + 0.0722f * Mathf.GammaToLinearSpace(surface.b);
            bool light = luminance > 0.179f;
            themeText = light ? Color.black : Color.white;
            checkboxOn = CheckboxTexture(surface, true);
            checkboxOff = CheckboxTexture(surface, false);
            themeMuted = themeText;
            themeAccent = themeText;
            chartBackground = Color.Lerp(secondary, Color.black, 0.8f);
            chartGrid = Color.Lerp(chartBackground, Color.white, 0.35f);
            Texture2D panel = Bevel(surface, false);
            Texture2D button = Bevel(Color.Lerp(secondary, Color.white, 0.1f), false);
            Texture2D hover = Bevel(Color.Lerp(secondary, Color.white, 0.22f), false);
            Texture2D pressed = Bevel(Color.Lerp(secondary, Color.black, 0.18f), true);
            Style(themedSkin.window, panel, panel, panel, themeText);
            themedSkin.window.border = new RectOffset(3, 3, 3, 3);
            themedSkin.window.padding = new RectOffset(10, 10, 25, 10);
            themedSkin.window.fontStyle = FontStyle.Bold;
            Color buttonBase = Color.Lerp(secondary, Color.white, 0.1f);
            float buttonLuminance = 0.2126f * Mathf.GammaToLinearSpace(buttonBase.r) + 0.7152f * Mathf.GammaToLinearSpace(buttonBase.g) + 0.0722f * Mathf.GammaToLinearSpace(buttonBase.b);
            Style(themedSkin.button, button, hover, pressed, buttonLuminance > 0.179f ? Color.black : Color.white);
            themedSkin.button.border = new RectOffset(3, 3, 3, 3);
            themedSkin.button.padding = new RectOffset(6, 6, 4, 4);
            Style(themedSkin.box, panel, panel, panel, themeText);
            themedSkin.label.normal.textColor = themeText;
            themedSkin.label.fontSize = 15;
            themedSkin.toggle.fontSize = 14;
            themedSkin.toggle.normal.textColor = themeText;
            themedSkin.toggle.onNormal.textColor = themeText;
            themedSkin.toggle.hover.textColor = themeText;
            themedSkin.toggle.onHover.textColor = themeText;
            themedSkin.button.fontSize = 14;
            themedSkin.button.fontStyle = FontStyle.Bold;
            themedSkin.window.fontSize = 15;
            heading = null; valueStyle = null; note = null;
        }

        private static void Style(GUIStyle style, Texture2D normal, Texture2D hover, Texture2D pressed, Color text)
        {
            style.normal.background = normal; style.hover.background = hover;
            style.active.background = pressed; style.focused.background = hover;
            style.onNormal.background = pressed; style.onHover.background = pressed;
            style.onActive.background = pressed; style.onFocused.background = pressed;
            foreach (GUIStyleState state in new[] { style.normal, style.hover, style.active, style.focused, style.onNormal, style.onHover, style.onActive, style.onFocused })
                state.textColor = text;
        }

        private Texture2D Bevel(Color surface, bool inset)
        {
            const int size = 16;
            var pixels = new Color[size * size];
            Color shine = Color.Lerp(surface, Color.white, 0.65f);
            Color shade = Color.Lerp(surface, Color.black, 0.75f);
            for (int y = 0; y < size; y++)
                for (int x = 0; x < size; x++)
                {
                    Color color = surface;
                    if (x < 2 || y >= size - 2) color = inset ? shade : shine;
                    else if (x >= size - 2 || y < 2) color = inset ? shine : shade;
                    pixels[y * size + x] = color;
                }
            var texture = new Texture2D(size, size, TextureFormat.RGBA32, false);
            texture.hideFlags = HideFlags.HideAndDontSave;
            texture.filterMode = FilterMode.Point;
            texture.wrapMode = TextureWrapMode.Clamp;
            texture.SetPixels(pixels); texture.Apply(false, true);
            themeTextures.Add(texture);
            return texture;
        }

        private void ReleaseTheme()
        {
            if (themedSkin != null) Destroy(themedSkin);
            foreach (var texture in themeTextures) if (texture != null) Destroy(texture);
            themeTextures.Clear();
        }
    }
}
