using System;
using System.Collections.Generic;
using UnityEngine;

namespace ScreenStocksStats
{
    public sealed partial class Plugin
    {
        private sealed class StockChart
        {
            public string Ticker, StockId;
            public float Price, PreferredMin, PreferredMax;
            public int VisibleSamples;
            public float[] Samples;
            public Texture2D Texture;
            public int StrokeRadius;
            public BigNumber LongShares, ShortShares;
            public float AverageBuy, AverageShort;
        }

        private void RefreshCharts(GameManager gm, StockManager sm)
        {
            if (gm.Settings == null || gm.Settings.allStocks == null) return;
            var previous = new Dictionary<string, StockChart>();
            foreach (var chart in charts) previous[chart.Ticker] = chart;
            charts.Clear();
            var seen = new HashSet<string>(StringComparer.Ordinal);
            foreach (var stock in gm.Settings.allStocks)
            {
                if (stock == null || !stock.IsAvailableInCurrentEdition || string.IsNullOrEmpty(stock.stockId) || !seen.Add(stock.stockId)) continue;
                var history = sm.GetPriceHistory(stock.stockId);
                int count = history == null ? 0 : history.Count;
                int visible = Mathf.Clamp(gm.Settings.chartVisibleTicks, 20, Mathf.Max(20, gm.Settings.historyLength));
                int start = Math.Max(0, count - visible);
                var points = new List<float>(count - start);
                for (int i = start; i < count; i++)
                {
                    float value = history[i];
                    // Preserve missing samples as gaps rather than inventing prices.
                    points.Add(value > 0 && !float.IsInfinity(value) ? value : float.NaN);
                }
                var next = new StockChart { StockId = stock.stockId, Ticker = stock.stockId.TrimStart('$'), Price = sm.GetCurrentPrice(stock.stockId), Samples = points.ToArray(), PreferredMin = stock.graphMinY, PreferredMax = stock.graphMaxY, VisibleSamples = visible, StrokeRadius = strokeRadius.Value };
                var position = gm.Data.GetPosition(stock.stockId);
                if (position != null)
                {
                    next.LongShares = position.sharesOwned;
                    next.ShortShares = position.sharesShorted;
                    next.AverageBuy = position.averageBuyPrice;
                    next.AverageShort = position.averageShortPrice;
                }
                StockChart old;
                if (previous.TryGetValue(next.Ticker, out old))
                {
                    bool same = old.Samples.Length == next.Samples.Length && old.VisibleSamples == visible && old.PreferredMin == next.PreferredMin && old.PreferredMax == next.PreferredMax && old.StrokeRadius == next.StrokeRadius;
                    for (int i = 0; same && i < next.Samples.Length; i++) same = old.Samples[i].Equals(next.Samples[i]);
                    if (same) { next.Texture = old.Texture; old.Texture = null; }
                }
                charts.Add(next);
            }
            foreach (var old in previous.Values) if (old.Texture != null) Destroy(old.Texture);
            charts.Sort((a, b) => string.Compare(a.Ticker, b.Ticker, StringComparison.Ordinal));
        }

        private void DrawCharts()
        {
            GUILayout.Label("LIVE STOCKS", heading);
            GUILayout.Label("Game chart ranges and history window · live refresh · unrealized P/L before closing impact", note);
            if (charts.Count == 0) { GUILayout.Label("Waiting for the stock catalog..."); return; }
            int columns = Mathf.Clamp(Mathf.FloorToInt((window.width - 42f) / 250f), 1, 6);
            int rows = (charts.Count + columns - 1) / columns;
            bool bothSides = charts.Exists(c => c.LongShares > BigNumber.Zero && c.ShortShares > BigNumber.Zero);
            float height = chartHeight.Value + (bothSides ? 210f : 135f);
            // Ordinarily all cards fit in the window; larger future catalogs can scroll.
            Rect area = GUILayoutUtility.GetRect(0, rows * height, GUILayout.ExpandWidth(true));

            float width = area.width / columns;
            for (int i = 0; i < charts.Count; i++)
            {
                Rect card = new Rect(area.x + i % columns * width + 3, area.y + i / columns * height + 3, width - 6, height - 6);
                if (clickChartSelects.Value && GUI.Button(card, GUIContent.none, GUIStyle.none)) pendingChartStock = charts[i].StockId;
                if (Event.current.type == EventType.Repaint) DrawChart(card, charts[i]);
            }
        }

        private string pendingChartStock;
        private void ProcessChartSelection()
        {
            if (string.IsNullOrEmpty(pendingChartStock)) return;
            string id = pendingChartStock;
            pendingChartStock = null;
            var gm = GameManager.I;
            var sm = StockManager.I;
            if (!clickChartSelects.Value || gm == null || sm == null || TutorialInputLock.IsActive) return;
            var stock = sm.GetStockSO(id);
            if (stock == null || !gm.IsStockSelectable(stock)) return;
            foreach (var button in UnityEngine.Object.FindObjectsByType<StockButtonUI>(FindObjectsInactive.Include, FindObjectsSortMode.None))
            {
                if (button.stock == null || button.stock.stockId != id) continue;
                button.TrySelectStock();
                if (button.viewToQuit != null) button.viewToQuit.QuitView();
                if (button.viewToShow != null) button.viewToShow.ShowView();
                return;
            }
            foreach (var graph in UnityEngine.Object.FindObjectsByType<StockGraphVisualizer>(FindObjectsSortMode.None)) graph.SetStock(stock);
            gm.SelectStock(stock);
        }

        private void DrawChart(Rect card, StockChart chart)
        {
            Color cardColor = chartBackground;
            cardColor.a = 1f - transparency.Value / 100f;
            Fill(card, cardColor);
            var chartHeading = new GUIStyle(heading); chartHeading.normal.textColor = Color.white;
            var chartValue = new GUIStyle(valueStyle); chartValue.normal.textColor = priceColor;
            var chartNote = new GUIStyle(note); chartNote.normal.textColor = Color.white;
            chartHeading.wordWrap = true;
            chartValue.alignment = TextAnchor.UpperRight;
            float contentWidth = card.width - 14;
            string ticker = "$" + chart.Ticker;
            bool validPrice = chart.Price > 0 && !float.IsNaN(chart.Price) && !float.IsInfinity(chart.Price);
            string priceText = validPrice ? "$" + chart.Price.ToString("0.00") : "Waiting...";
            float priceWidth = Mathf.Min(contentWidth * 0.48f, chartValue.CalcSize(new GUIContent(priceText)).x + 8);
            while (chartValue.fontSize > 12 && chartValue.CalcSize(new GUIContent(priceText)).x > priceWidth) chartValue.fontSize--;
            float tickerWidth = contentWidth - priceWidth - 8;
            float headerHeight = Mathf.Max(30, chartHeading.CalcHeight(new GUIContent(ticker), tickerWidth) + 6);
            GUI.Label(new Rect(card.x + 7, card.y + 4, tickerWidth, headerHeight), ticker, chartHeading);
            GUI.Label(new Rect(card.xMax - 7 - priceWidth, card.y + 5, priceWidth, headerHeight), priceText, chartValue);
            float statsTop = card.y + headerHeight + 7;
            if (chart.LongShares > BigNumber.Zero)
                statsTop = DrawPositionStats(card, statsTop, "Avg buy", chart.AverageBuy, chart.LongShares, chart.Price, false, validPrice);
            if (chart.ShortShares > BigNumber.Zero)
                statsTop = DrawPositionStats(card, statsTop, "Avg short", chart.AverageShort, chart.ShortShares, chart.Price, true, validPrice);
            if (chart.LongShares <= BigNumber.Zero && chart.ShortShares <= BigNumber.Zero)
            {
                GUI.Label(new Rect(card.x + 7, statsTop, contentWidth, 28), "No open position", chartNote);
                statsTop += 30;
            }
            float plotTop = statsTop + 8;
            Rect plot = new Rect(card.x + 7, plotTop, contentWidth, chartHeight.Value);
            float low = float.PositiveInfinity, high = float.NegativeInfinity, first = 0, last = 0;
            int valid = 0;
            foreach (float sample in chart.Samples)
            {
                if (float.IsNaN(sample)) continue;
                low = Mathf.Min(low, sample); high = Mathf.Max(high, sample);
                if (valid++ == 0) first = sample;
                last = sample;
            }
            if (valid < 2)
            {
                GUI.Label(plot, "Waiting for price history...", chartNote);
                return;
            }
            // Match UILineGraph preferred-bound behavior instead of stretching every
            // tiny fluctuation to the full height of the card.
            float min = Mathf.Max(0f, Mathf.Min(chart.PreferredMin, low));
            float max = Mathf.Max(chart.PreferredMax, high);
            if (float.IsNaN(min) || float.IsInfinity(min)) min = Mathf.Max(0, low);
            if (float.IsNaN(max) || float.IsInfinity(max) || max <= min) max = min + Mathf.Max(1f, high * 0.1f);
            if (showGrid.Value) for (int i = 0; i < 3; i++) Fill(new Rect(plot.x, plot.y + i * plot.height / 2, plot.width, 1.4f), chartGrid);
            Color color = last >= first ? new Color(0.3f, 0.95f, 0.7f) : new Color(1f, 0.4f, 0.48f);
            if (chart.Texture == null) chart.Texture = Rasterize(chart.Samples, chart.VisibleSamples, min, max, color, strokeRadius.Value);
            GUI.DrawTexture(plot, chart.Texture, ScaleMode.StretchToFill, true);
        }

        private float DrawPositionStats(Rect card, float top, string label, float average, BigNumber shares, float price, bool isShort, bool validPrice)
        {
            float width = card.width - 14;
            var entryStyle = new GUIStyle(GUI.skin.label) { fontSize = 14, fontStyle = FontStyle.Bold };
            entryStyle.normal.textColor = Color.white;
            GUI.Label(new Rect(card.x + 7, top, width, 25), label + ": $" + average.ToString("0.00"), entryStyle);
            top += 26;
            var gainStyle = new GUIStyle(entryStyle) { wordWrap = true, padding = new RectOffset(5, 5, 4, 4) };
            string gainText = "P/L unavailable";
            if (validPrice && average > 0)
            {
                float difference = isShort ? average - price : price - average;
                BigNumber profit = shares * (BigNumber)difference;
                float percent = difference / average * 100f;
                string marker = difference > 0 ? "▲ " : difference < 0 ? "▼ " : "= ";
                gainText = marker + MoneyFormatter.Format(profit, true) + "  (" + percent.ToString("+0.00;-0.00;0.00") + "%)";
                gainStyle.normal.textColor = difference > 0 ? new Color(0.2f, 1f, 0.35f) : difference < 0 ? new Color(1f, 0.36f, 0.4f) : Color.white;
            }
            float height = Mathf.Max(28, gainStyle.CalcHeight(new GUIContent(gainText), width) + 2);
            // Opaque backing keeps gain/loss colors readable at any window transparency.
            Fill(new Rect(card.x + 7, top, width, height), new Color(0.025f, 0.03f, 0.04f, 1));
            GUI.Label(new Rect(card.x + 7, top, width, height), gainText, gainStyle);
            return top + height + 4;
        }

        private static void Fill(Rect rect, Color color)
        {
            Color old = GUI.color;
            GUI.color = color;
            GUI.DrawTexture(rect, Texture2D.whiteTexture);
            GUI.color = old;
        }

        private void ReleaseChartTextures()
        {
            foreach (var chart in charts)
                if (chart.Texture != null) Destroy(chart.Texture);
        }

        // Rasterize in chart-local pixels. One rectangular draw lets Unity handle
        // window movement, scrolling and GUI scaling without rotating its clip space.
        private static Texture2D Rasterize(float[] samples, int visibleSamples, float min, float max, Color color, int radius)
        {
            const int width = 384, height = 160;
            var pixels = new Color32[width * height];
            Color32 ink = color;
            for (int i = 1; i < samples.Length; i++)
            {
                float a = samples[i - 1], b = samples[i];
                if (float.IsNaN(a) || float.IsNaN(b)) continue;
                float x0 = (i - 1f) / (Mathf.Max(2, visibleSamples) - 1) * (width - 1);
                float x1 = (float)i / (Mathf.Max(2, visibleSamples) - 1) * (width - 1);
                float y0 = Mathf.Clamp01((a - min) / (max - min)) * (height - 1);
                float y1 = Mathf.Clamp01((b - min) / (max - min)) * (height - 1);
                int steps = Mathf.Max(1, Mathf.CeilToInt(Mathf.Max(Mathf.Abs(x1 - x0), Mathf.Abs(y1 - y0))));
                for (int step = 0; step <= steps; step++)
                {
                    float t = (float)step / steps;
                    int x = Mathf.Clamp(Mathf.RoundToInt(Mathf.Lerp(x0, x1, t)), 0, width - 1);
                    int y = Mathf.Clamp(Mathf.RoundToInt(Mathf.Lerp(y0, y1, t)), 0, height - 1);
                    // A five-pixel round stroke remains visible when reduced to a card.
                    for (int dy = -radius; dy <= radius; dy++)
                        for (int dx = -radius; dx <= radius; dx++)
                        {
                            int px = x + dx, py = y + dy;
                            if (dx * dx + dy * dy <= radius * radius + 1 && px >= 0 && px < width && py >= 0 && py < height)
                                pixels[py * width + px] = ink;
                        }
                }
            }
            var texture = new Texture2D(width, height, TextureFormat.RGBA32, false);
            texture.hideFlags = HideFlags.HideAndDontSave;
            texture.wrapMode = TextureWrapMode.Clamp;
            texture.filterMode = FilterMode.Bilinear;
            texture.SetPixels32(pixels);
            texture.Apply(false, true);
            return texture;
        }
    }
}
