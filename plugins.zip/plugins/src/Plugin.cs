using System;
using System.Collections.Generic;
using BepInEx;
using BepInEx.Configuration;
using UnityEngine;

namespace ScreenStocksStats
{
    [BepInPlugin("dunn.screenstocks.stats", "Screen Stocks Stats", PluginInfo.Version)]
    public sealed partial class Plugin : BaseUnityPlugin
    {
        private ConfigEntry<KeyCode> toggleKey;
        private ConfigEntry<bool> visible;
        private ConfigEntry<float> savedScale;
        private float panelScale;
        private Vector2 panelPosition = new Vector2(18, 80);
        private ConfigEntry<float> savedLeft, savedTop;
        private bool positionDirty;
        private Vector2 resizeStartMouse;
        private Rect resizeStartBounds;
        private bool resizeLeft, resizeRight, resizeTop, resizeBottom, resizing, movingWindow;
        private ConfigEntry<float> savedWidth, savedHeight;
        private Vector2 panelSize = new Vector2(380, 620);
        private float PanelWidth => panelSize.x;
        private float PanelHeight => panelSize.y;
        private Rect window = new Rect(18, 80, 380, 620);
        private Vector2 scroll;
        private GUIStyle heading, valueStyle, note;
        private int tab;
        private StockManager subscribed;
        private GameData trackedData;
        private int ipo;
        private bool ready;
        private float started, nextRefresh, nextError;
        private BigNumber baselineWorth, baselineLong, baselineShort, dividends;
        private BigNumber cash, worth, longs, shorts;
        private int level;
        private string status = "Waiting for your game session...", buyCooldown = "—", shortCooldown = "—", dividendTimer = "—";
        private readonly List<StockChart> charts = new List<StockChart>();
        private readonly List<Holding> holdings = new List<Holding>();
        private sealed class Holding
        {
            public string Ticker, Side;
            public BigNumber Shares, Value, Profit;
            public float Average, Price;
        }

        private void Awake()
        {
            toggleKey = Config.Bind("Display", "ToggleKey", KeyCode.F8, "Show or hide the stats panel. On Mac you may need Fn+F8.");
            visible = Config.Bind("Display", "Visible", true, "Show the panel at startup.");
            savedScale = Config.Bind("Display", "PanelScale", 1.75f, new ConfigDescription("Text and control scale. Use A- / A+ in the panel; edges resize width and height independently.", new AcceptableValueRange<float>(0.75f, 3f)));
            panelScale = savedScale.Value;
            savedWidth = Config.Bind("Display", "WindowWidthPixels", Config.Bind("Display", "WindowWidth", 380f).Value * savedScale.Value, new ConfigDescription("Window width in screen pixels.", new AcceptableValueRange<float>(300, 4000)));
            savedHeight = Config.Bind("Display", "WindowHeightPixels", Config.Bind("Display", "WindowHeight", 620f).Value * savedScale.Value, new ConfigDescription("Window height in screen pixels.", new AcceptableValueRange<float>(240, 4000)));
            savedLeft = Config.Bind("Display", "WindowLeft", 18f, "Saved window left position in screen pixels.");
            savedTop = Config.Bind("Display", "WindowTop", 80f, "Saved window top position in screen pixels.");
            panelPosition = new Vector2(savedLeft.Value, savedTop.Value);
            InitSettings();
            Logger.LogInfo("Stats-only plugin loaded. No trade actions, automation, or game-state patches.");
        }

        private void Update()
        {
            ProcessChartSelection();
            // Legacy input is available in this game; a clickable button is also provided.
            if (Input.GetKeyDown(toggleKey.Value)) visible.Value = !visible.Value;
            if (Time.realtimeSinceStartup < nextRefresh) return;
            nextRefresh = Time.realtimeSinceStartup + (fastestRefresh.Value ? 0f : refreshSeconds.Value);
            try { Refresh(); }
            catch (Exception error)
            {
                status = "Data unavailable; retrying. See BepInEx log.";
                ready = false;
                if (Time.realtimeSinceStartup >= nextError)
                {
                    Logger.LogWarning(error);
                    nextError = Time.realtimeSinceStartup + 30f;
                }
            }
        }

        private void Refresh()
        {
            var gm = GameManager.I;
            var sm = StockManager.I;
            if (gm == null || sm == null || gm.Data == null || !gm.HasCompletedOfflineProgress)
            {
                ready = false;
                status = "Waiting for your game session...";
                Unsubscribe();
                return;
            }
            if (subscribed != sm)
            {
                Unsubscribe();
                subscribed = sm;
                subscribed.OnDividendPaid += OnDividend;
                ready = false;
            }
            if (!ready || trackedData != gm.Data || ipo != gm.RawIPOCount) ResetSession();
            cash = gm.Money;
            worth = gm.CalculateNetWorth();
            level = gm.PlayerLevel;
            longs = gm.Data.lifetimeBuyingProfit - baselineLong;
            shorts = gm.Data.lifetimeShortingProfit - baselineShort;
            buyCooldown = Cooldown(gm.Data.nextBuyTradeAvailableTimestamp);
            shortCooldown = Cooldown(gm.Data.nextShortTradeAvailableTimestamp);
            dividendTimer = Math.Max(0f, sm.GetGlobalDividendTimeRemaining()).ToString("0.0") + "s";
            RefreshCharts(gm, sm);
            holdings.Clear();
            foreach (var position in gm.Data.stockPositions)
            {
                if (position == null) continue;
                float price = sm.GetCurrentPrice(position.stockId);
                if (position.sharesOwned > BigNumber.Zero)
                    holdings.Add(new Holding { Ticker = position.stockId, Side = "LONG", Shares = position.sharesOwned,
                        Average = position.averageBuyPrice, Price = price, Value = position.sharesOwned * (BigNumber)price,
                        Profit = position.sharesOwned * (BigNumber)(price - position.averageBuyPrice) });
                if (position.sharesShorted > BigNumber.Zero)
                    holdings.Add(new Holding { Ticker = position.stockId, Side = "SHORT", Shares = position.sharesShorted,
                        Average = position.averageShortPrice, Price = price,
                        Value = position.lockedCollateral + position.sharesShorted * (BigNumber)(position.averageShortPrice - price),
                        Profit = position.sharesShorted * (BigNumber)(position.averageShortPrice - price) });
            }
            status = sm.IsUsingRemoteServer ? "LIVE  /  READ ONLY" : "LOCAL  /  READ ONLY";
        }

        private void ResetSession()
        {
            var gm = GameManager.I;
            if (gm == null || gm.Data == null) return;
            trackedData = gm.Data;
            ipo = gm.RawIPOCount;
            baselineWorth = gm.CalculateNetWorth();
            baselineLong = gm.Data.lifetimeBuyingProfit;
            baselineShort = gm.Data.lifetimeShortingProfit;
            dividends = longs = shorts = BigNumber.Zero;
            started = Time.realtimeSinceStartup;
            ready = true;
        }

        private void OnDividend(string stockId, BigNumber amount)
        {
            if (ready && GameManager.I != null && GameManager.I.Data == trackedData && GameManager.I.RawIPOCount == ipo)
                dividends += amount;
        }

        private void Unsubscribe()
        {
            if (!ReferenceEquals(subscribed, null)) subscribed.OnDividendPaid -= OnDividend;
            subscribed = null;
        }
        private void OnDestroy() { SaveWindowPosition(); Unsubscribe(); ReleaseChartTextures(); ReleaseTheme(); }
        private void OnApplicationQuit() { SaveWindowPosition(); }
        private void SaveWindowPosition()
        {
            if (!positionDirty || savedLeft == null || savedTop == null) return;
            savedLeft.Value = Mathf.Round(panelPosition.x);
            savedTop.Value = Mathf.Round(panelPosition.y);
            positionDirty = false;
        }
        private static string Money(BigNumber amount) { return MoneyFormatter.Format(amount); }
        private static string Cooldown(long timestamp)
        {
            long now = (long)(DateTime.UtcNow - new DateTime(1970, 1, 1)).TotalSeconds;
            return timestamp > now ? (timestamp - now) + "s" : "Ready";
        }

        private void DrawThemedGUI()
        {
            if (heading == null)
            {
                heading = new GUIStyle(GUI.skin.label) { fontSize = 19, fontStyle = FontStyle.Bold };
                heading.normal.textColor = themeAccent;
                valueStyle = new GUIStyle(GUI.skin.label) { alignment = TextAnchor.MiddleRight, fontSize = 16, fontStyle = FontStyle.Bold };
                note = new GUIStyle(GUI.skin.label) { wordWrap = true, fontSize = 13 };
                note.normal.textColor = themeMuted;
            }
            if (!visible.Value)
            {
                if (GUI.Button(new Rect(10, 10, 115, 28), "Show stats")) visible.Value = true;
                return;
            }
            panelScale = Mathf.Min(savedScale.Value, Mathf.Min(Screen.width / 300f, Screen.height / 240f));
            if (!resizing) panelSize = new Vector2(savedWidth.Value, savedHeight.Value) / panelScale;
            panelSize.x = Mathf.Min(panelSize.x, Screen.width / panelScale);
            panelSize.y = Mathf.Min(panelSize.y, Screen.height / panelScale);
            if (!resizing && !movingWindow) panelPosition = new Vector2(savedLeft.Value, savedTop.Value);
            panelPosition.x = Mathf.Clamp(panelPosition.x, 0, Mathf.Max(0, Screen.width - PanelWidth * panelScale));
            panelPosition.y = Mathf.Clamp(panelPosition.y, 0, Mathf.Max(0, Screen.height - PanelHeight * panelScale));
            HandleResize(new Rect(panelPosition.x, panelPosition.y, PanelWidth * panelScale, PanelHeight * panelScale));
            var previousMatrix = GUI.matrix;
            var previousColor = GUI.backgroundColor;
            try
            {
                GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, new Vector3(panelScale, panelScale, 1));
                window = new Rect(panelPosition.x / panelScale, panelPosition.y / panelScale, PanelWidth, PanelHeight);
                GUI.backgroundColor = new Color(1, 1, 1, 1f - transparency.Value / 100f);
                window = GUI.Window(735891, window, DrawWindow, "SCREEN STOCKS  /  STATS");

            }
            finally
            {
                GUI.matrix = previousMatrix;
                GUI.backgroundColor = previousColor;
            }
        }

        private void HandleResize(Rect bounds)
        {
            int control = GUIUtility.GetControlID(735892, FocusType.Passive);
            Event e = Event.current;
            const float grip = 9;
            bool left = new Rect(bounds.x - 3, bounds.y, grip + 3, bounds.height).Contains(e.mousePosition);
            bool right = new Rect(bounds.xMax - grip, bounds.y, grip + 3, bounds.height).Contains(e.mousePosition);
            bool top = new Rect(bounds.x, bounds.y - 3, bounds.width, grip + 3).Contains(e.mousePosition);
            bool bottom = new Rect(bounds.x, bounds.yMax - grip, bounds.width, grip + 3).Contains(e.mousePosition);
            bool title = new Rect(bounds.x + grip, bounds.y + grip, Mathf.Max(0, bounds.width - 2 * grip), Mathf.Max(0, 22 * panelScale - grip)).Contains(e.mousePosition);
            if (e.type == EventType.MouseDown && e.button == 0 && (left || right || top || bottom || title))
            {
                GUIUtility.hotControl = control;
                movingWindow = title && !(left || right || top || bottom);
                resizing = !movingWindow;
                resizeLeft = left; resizeRight = right; resizeTop = top; resizeBottom = bottom;
                resizeStartMouse = e.mousePosition;
                resizeStartBounds = bounds;
                e.Use();
            }
            else if (GUIUtility.hotControl == control && e.type == EventType.MouseDrag)
            {
                Vector2 delta = e.mousePosition - resizeStartMouse;
                Rect r = resizeStartBounds;
                if (movingWindow)
                {
                    panelPosition = new Vector2(
                        Mathf.Clamp(r.x + delta.x, 0, Mathf.Max(0, Screen.width - r.width)),
                        Mathf.Clamp(r.y + delta.y, 0, Mathf.Max(0, Screen.height - r.height)));
                    positionDirty = true;
                    e.Use();
                    return;
                }
                float minWidth = Mathf.Min(300, Screen.width);
                float minHeight = Mathf.Min(240, Screen.height);
                if (resizeLeft) r.xMin = Mathf.Clamp(r.xMin + delta.x, 0, r.xMax - minWidth);
                if (resizeRight) r.xMax = Mathf.Clamp(r.xMax + delta.x, r.xMin + minWidth, Screen.width);
                if (resizeTop) r.yMin = Mathf.Clamp(r.yMin + delta.y, 0, r.yMax - minHeight);
                if (resizeBottom) r.yMax = Mathf.Clamp(r.yMax + delta.y, r.yMin + minHeight, Screen.height);
                panelPosition = r.position;
                positionDirty = true;
                panelSize = r.size / panelScale;
                e.Use();
            }
            else if (GUIUtility.hotControl == control && e.rawType == EventType.MouseUp)
            {
                GUIUtility.hotControl = 0;
                bool didResize = resizing;
                resizing = false;
                movingWindow = false;
                SaveWindowPosition();
                if (!didResize) { e.Use(); return; }
                savedWidth.Value = Mathf.Round(panelSize.x * panelScale);
                savedHeight.Value = Mathf.Round(panelSize.y * panelScale);
                e.Use();
            }
        }

        private void DrawWindow(int id)
        {
            GUILayout.BeginHorizontal();
            GUILayout.Label(status, note);
            if (GUILayout.Button("A-", GUILayout.Width(38))) savedScale.Value = Mathf.Max(0.75f, savedScale.Value - 0.01f);
            if (GUILayout.Button("A+", GUILayout.Width(38))) savedScale.Value = Mathf.Min(3f, savedScale.Value + 0.01f);
            if (GUILayout.Button("Hide", GUILayout.Width(48))) visible.Value = false;
            GUILayout.EndHorizontal();
            tab = GUILayout.Toolbar(tab, new[] { "Overview", "Holdings", "Stocks", "Settings" }, new GUIStyle(GUI.skin.button) { fontSize = 12 });
            scroll = GUILayout.BeginScrollView(scroll);
            if (tab == 3) DrawSettings();
            else if (!ready) GUILayout.Label(status);
            else if (tab == 0)
            {
                GUILayout.Label("PORTFOLIO", heading);
                Row("Cash", cash);
                Row("Positions equity", worth - cash);
                Row("Net worth", worth);
                Row("Level", level.ToString());
                GUILayout.Space(10);
                GUILayout.Label("THIS SESSION", heading);
                Row("Long trades · realized", longs);
                Row("Short trades · realized", shorts);
                Row("Dividends · net observed", dividends);
                Row("Trades + dividends", longs + shorts + dividends);
                Row("Net-worth change", worth - baselineWorth);
                double seconds = Math.Max(0, Time.realtimeSinceStartup - started);
                Row("Elapsed", TimeSpan.FromSeconds(seconds).ToString(@"hh\:mm\:ss"));
                Row("Trades + dividends / hour", seconds >= 60 ? Money((longs + shorts + dividends) * (BigNumber)(3600.0 / seconds)) : "Collecting · first 60s");
                GUILayout.Label("Hourly value is a session average, not a forecast. Net-worth change includes market moves and spending. Offline payouts before tracking are excluded.", note);
                GUILayout.Space(10);
                GUILayout.Label("TIMERS", heading);
                Row("Buy cooldown", buyCooldown);
                Row("Short cooldown", shortCooldown);
                Row("Next dividend boundary", dividendTimer);
                GUILayout.Space(8);
                if (GUILayout.Button("Reset session stats")) ResetSession();
                GUILayout.Label("Reset affects this panel only. Session totals reset on restart, data reload, or IPO.", note);
            }
            else if (tab == 2) DrawCharts();
            else
            {
                GUILayout.Label("OPEN POSITIONS", heading);
                if (holdings.Count == 0) GUILayout.Label("No open positions.");
                foreach (var item in holdings)
                {
                    GUILayout.Label("$" + item.Ticker + "  ·  " + item.Side, heading);
                    Row("Shares", item.Shares.ToShortStringSignificant(4));
                    Row("Average entry", "$" + item.Average.ToString("0.00"));
                    Row("Current price", "$" + item.Price.ToString("0.00"));
                    Row(item.Side == "LONG" ? "Market value" : "Collateral + P/L", item.Value);
                    Row("Unrealized P/L", item.Profit);
                    GUILayout.Space(9);
                }
                GUILayout.Label("Values use current quoted prices, before any closing price impact. Short value includes locked collateral.", note);
            }
            GUILayout.EndScrollView();
            GUILayout.Label("Drag edges to resize  ·  " + toggleKey.Value + " to toggle", note);
            var versionStyle = new GUIStyle(note) { alignment = TextAnchor.MiddleCenter, fontStyle = FontStyle.Bold };
            GUILayout.Label("v" + PluginInfo.Version, versionStyle, GUILayout.Height(24));
            GUI.Label(new Rect(window.width - 22, window.height - 23, 20, 20), "◢", heading);
            // Title movement is handled in screen coordinates by HandleResize.
        }

        private void Row(string label, BigNumber number) { Row(label, Money(number)); }
        private void Row(string label, string text)
        {
            // A shared, measured row prevents independent live labels from clipping.
            var labelStyle = new GUIStyle(GUI.skin.label)
            {
                alignment = TextAnchor.UpperLeft, wordWrap = true,
                fixedHeight = 0, padding = new RectOffset(2, 2, 4, 4)
            };
            var numberStyle = new GUIStyle(valueStyle)
            {
                alignment = TextAnchor.UpperRight, wordWrap = true,
                fixedHeight = 0, padding = new RectOffset(2, 2, 4, 4)
            };
            float available = Mathf.Max(120, window.width - 50);
            float valueWidth = available * 0.40f;
            float labelWidth = available - valueWidth - 10;
            float height = Mathf.Max(32, Mathf.Max(
                labelStyle.CalcHeight(new GUIContent(label), labelWidth),
                numberStyle.CalcHeight(new GUIContent(text), valueWidth)) + 6);
            Rect row = GUILayoutUtility.GetRect(0, height, GUILayout.ExpandWidth(true), GUILayout.MinHeight(height));
            GUI.Label(new Rect(row.x, row.y + 2, labelWidth, row.height - 2), label, labelStyle);
            GUI.Label(new Rect(row.xMax - valueWidth, row.y + 2, valueWidth, row.height - 2), text, numberStyle);
        }
    }
}
