using BepInEx.Configuration;
using UnityEngine;

namespace ScreenStocksStats
{
    public sealed partial class Plugin
    {
        private ConfigEntry<bool> followTheme, showGrid, fastestRefresh, clickChartSelects;
        private ConfigEntry<int> strokeRadius;
        private ConfigEntry<float> refreshSeconds, transparency, chartHeight;
        private ConfigEntry<string> priceHex, primaryHex, secondaryHex;
        private string primaryInput, secondaryInput;
        private string hexInput;
        private Color priceColor = Color.white;

        private void InitSettings()
        {
            primaryHex = Config.Bind("Appearance", "PrimaryHex", "#293045", "Custom window background hex color #RRGGBB.");
            secondaryHex = Config.Bind("Appearance", "SecondaryHex", "#485875", "Custom button and chart accent hex color #RRGGBB.");
            primaryInput = primaryHex.Value;
            secondaryInput = secondaryHex.Value;
            fastestRefresh = Config.Bind("Display", "FastestRefresh", false, "Refresh once every rendered game frame, limited by available game data.");
            transparency = Config.Bind("Appearance", "TransparencyPercent", 0f, new ConfigDescription("Window background transparency, 0 opaque to 90 transparent.", new AcceptableValueRange<float>(0, 90)));
            priceHex = Config.Bind("Charts", "PriceColorHex", "#FFFFFF", "Chart price text color as a hex code #RRGGBB.");
            hexInput = priceHex.Value;
            Color parsed;
            if (ColorUtility.TryParseHtmlString(hexInput, out parsed)) priceColor = parsed;
            chartHeight = Config.Bind("Charts", "GraphHeight", 90f, new ConfigDescription("Graph area height in UI units; does not resize labels or the window.", new AcceptableValueRange<float>(30, 400)));
            clickChartSelects = Config.Bind("Charts", "ClickToSelectStock", false, "Click a chart to open that stock in the game. Never places a trade.");
            followTheme = Config.Bind("Appearance", "FollowGameTheme", true, "Use the equipped game skin; disabled uses your custom primary and secondary colors.");
            showGrid = Config.Bind("Charts", "ShowGrid", true, "Show chart grid lines.");
            strokeRadius = Config.Bind("Charts", "LineThickness", 2, new ConfigDescription("Chart stroke radius in texture pixels.", new AcceptableValueRange<int>(1, 3)));
            refreshSeconds = Config.Bind("Display", "RefreshSeconds", 0.5f, new ConfigDescription("Seconds between stats and chart updates.", new AcceptableValueRange<float>(0.25f, 2f)));
        }

        private void DrawSettings()
        {
            GUILayout.Label("SETTINGS  ·  v" + PluginInfo.Version, heading);
            GUILayout.Label("Changes save automatically and apply immediately.", note);
            GUILayout.Space(8);
            GUILayout.Label("APPEARANCE", heading);
            followTheme.Value = SettingsCheckbox(followTheme.Value, " Follow game theme");
            bool controlsEnabled = GUI.enabled;
            GUI.enabled = controlsEnabled && !followTheme.Value;
            DrawThemeHex("Primary — window background", ref primaryInput, primaryHex);
            DrawThemeHex("Secondary — buttons and chart accents", ref secondaryInput, secondaryHex);
            GUI.enabled = controlsEnabled;
            if (followTheme.Value) GUILayout.Label("Turn off Follow game theme to edit your custom colors.", note);
            Adjust("Text size", savedScale, 0.01f, 0.75f, 3f, "0", "%", 100f);
            Adjust("Transparency", transparency, 1f, 0, 90, "0", "%");
            GUILayout.Space(8);
            GUILayout.Label("WINDOW", heading);
            Adjust("Width", savedWidth, 1, 300, 4000, "0", "");
            Adjust("Height", savedHeight, 1, 240, 4000, "0", "");
            GUILayout.Label("Size is in screen pixels and is limited by your screen. You can also drag any edge or corner.", note);
            GUILayout.Space(8);
            GUILayout.Label("CHARTS", heading);
            clickChartSelects.Value = SettingsCheckbox(clickChartSelects.Value, " Click chart to open stock in-game");
            Adjust("Chart height", chartHeight, 1f, 30, 400, "0", "");
            GUILayout.Label("Changes only the graph area. Text and window size stay the same.", note);
            showGrid.Value = SettingsCheckbox(showGrid.Value, " Show grid lines");
            GUILayout.Label("Line weight");
            strokeRadius.Value = GUILayout.Toolbar(strokeRadius.Value - 1, new[] { "Fine", "Medium", "Bold" }) + 1;
            fastestRefresh.Value = SettingsCheckbox(fastestRefresh.Value, " Fastest refresh (every frame)");
            GUILayout.Label("Uses the latest data the game has; cannot make server prices arrive faster.", note);
            GUI.enabled = !fastestRefresh.Value;
            Adjust("Refresh", refreshSeconds, 0.25f, 0.25f, 2f, "0.00", "s");
            GUI.enabled = true;
            GUILayout.Space(8);
            GUILayout.Label("Stock price text color", heading);
            GUILayout.Label("Hex color code: #RRGGBB (example: #00FF88)", note);
            hexInput = GUILayout.TextField(hexInput, 7);
            Color candidate;
            string normalized = hexInput.StartsWith("#") ? hexInput : "#" + hexInput;
            bool validHex = normalized.Length == 7 && ColorUtility.TryParseHtmlString(normalized, out candidate);
            if (validHex)
            {
                ColorUtility.TryParseHtmlString(normalized, out candidate);
                priceColor = candidate;
                priceHex.Value = normalized.ToUpperInvariant();
                var preview = new GUIStyle(GUI.skin.label);
                preview.normal.textColor = priceColor;
                GUILayout.Label("Preview: $123.45", preview);
            }
            else GUILayout.Label("Enter 6 hex digits (0–9, A–F). Keeping the last valid color.", note);
            GUILayout.Space(8);
            GUILayout.Label("SHORTCUT", heading);
            GUILayout.Label("Toggle panel: " + toggleKey.Value + " (Fn may be needed on Mac)", note);
            GUILayout.Space(12);
            if (GUILayout.Button("Reset display settings"))
            {
                savedScale.Value = 1.75f;
                savedWidth.Value = 665;
                savedHeight.Value = 1085;
                followTheme.Value = true;
                primaryHex.Value = primaryInput = "#293045";
                secondaryHex.Value = secondaryInput = "#485875";
                showGrid.Value = true;
                clickChartSelects.Value = false;
                strokeRadius.Value = 2;
                chartHeight.Value = 90;
                refreshSeconds.Value = 0.5f;
                fastestRefresh.Value = false;
                transparency.Value = 0;
                priceHex.Value = hexInput = "#FFFFFF";
                priceColor = Color.white;
                panelPosition = new Vector2(18, 80);
                positionDirty = true;
                SaveWindowPosition();
            }
            GUILayout.Label("Reset keeps your session stats. This plugin remains read-only.", note);
        }

        private void DrawThemeHex(string label, ref string input, ConfigEntry<string> setting)
        {
            GUILayout.Label(label);
            GUILayout.Label("Hex color code: #RRGGBB", note);
            input = GUILayout.TextField(input, 7);
            string normalized = input.StartsWith("#") ? input : "#" + input;
            Color parsed;
            bool valid = normalized.Length == 7 && ColorUtility.TryParseHtmlString(normalized, out parsed);
            if (valid && GUI.enabled) setting.Value = normalized.ToUpperInvariant();
            else if (!valid) GUILayout.Label("Use 6 hex digits (0–9, A–F). Last valid color stays applied.", note);
        }

        private void Adjust(string label, ConfigEntry<float> setting, float step, float minimum, float maximum, string format, string suffix, float displayMultiplier = 1f)
        {
            GUILayout.BeginHorizontal();
            GUILayout.Label(label);
            GUILayout.FlexibleSpace();
            if (GUILayout.Button("−", GUILayout.Width(32))) setting.Value = Mathf.Clamp(setting.Value - step, minimum, maximum);
            GUILayout.Label((setting.Value * displayMultiplier).ToString(format) + suffix, valueStyle, GUILayout.Width(66), GUILayout.MinHeight(32));
            if (GUILayout.Button("+", GUILayout.Width(32))) setting.Value = Mathf.Clamp(setting.Value + step, minimum, maximum);
            GUILayout.EndHorizontal();
        }
    }
}
