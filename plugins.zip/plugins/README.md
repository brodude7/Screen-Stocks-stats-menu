# Screen Stocks Stats 0.1.20

Read-only BepInEx 5 plugin. Built against the local September 24, 2026 demo (Unity 6000.0.70f1). Same AnyCPU DLL intended for Windows and Mac with compatible game builds. In-game testing on both remains required.

## Install

Close the game. Copy only ScreenStocksStats-v0.1.20.dll into the game's BepInEx/plugins folder; create that folder if absent. Start through Steam with your working BepInEx launch settings. On Mac keep ARCHPREFERENCE="x86_64" in the launch script.

Mac destination:
/Users/dunn/Library/Application Support/Steam/steamapps/common/Screen Stocks Demo/BepInEx/plugins/ScreenStocksStats-v0.1.20.dll

Windows destination: <Screen Stocks Demo>/BepInEx/plugins/ScreenStocksStats-v0.1.20.dll

F8 (possibly Fn+F8 on Mac) toggles the draggable panel. Hide / Show stats buttons also work. Overview and Holdings tabs display cash, net worth, realized profits, observed net dividends, average earnings/hour, holdings and timers. Remove the DLL with the game closed to uninstall.

## Develop in VS Code

Open this folder. Edit src/Plugin.cs. Run Cmd+Shift+B or `bash build.sh`. The versioned DLL is saved in build/. Copy it into the game after each build while the game is closed.

The build script uses a system .NET SDK if present, otherwise the SDK installed at /Users/dunn/Documents/Codex/2026-09-26/you/work/dotnet. Keep that workspace folder for rebuilding. No NuGet packages are required. GameDir and ManagedDir in the project can be overridden for another installation. References are taken from your installed game, not bundled in the plugin.

## Accounting and limits

Tracking begins after offline progress finishes. Session stats reset on restart, game-data replacement, IPO count change, or Reset session stats. No session history is saved. Reset only affects this panel.

Realized profits are differences in the game's lifetime long/short profit counters. Dividends are net events observed while tracking; earlier/offline payouts are excluded. Earnings/hour is the session average after the first 60 seconds, not a prediction. Net-worth change includes market moves and spending and is not realized profit.

Holdings use current quotes before closing price impact. Short equity is locked collateral plus quoted short P/L. Cooldowns use local UTC time. The dividend timer shows the global boundary; it does not guarantee a payout on your holdings.

No automation, trade/upgrade calls, network requests, Harmony patches, or game-save writes. Only the plugin's own display settings are saved.

## Validation

Release build: zero warnings and errors. Verified managed IL-only AnyCPU flags and inspected compiled calls for absence of trading/upgrade calls or game-field writes. Runtime rendering and Windows compatibility remain unverified.

After installing, check BepInEx/LogOutput.log for Screen Stocks Stats 0.1.2 and the stats-only startup message. Compare cash, net worth and holdings against the game; verify a manual sale/cover and dividend update session totals. Test Hide, Show stats, F8, dragging and Reset session stats. Repeat on Windows.

## Resizing (0.1.2)

Starts at 175% scale. Drag the right edge, bottom edge, or bottom-right corner to scale the entire panel, including text and controls. Drag the title to move. Scale is saved on release under Display / PanelScale in BepInEx/config/dunn.screenstocks.stats.cfg. The panel is constrained to the screen. Resize behavior needs an in-game check.

## Versioned builds

Change the Version property in ScreenStocksStats.csproj for a new release. This sets the filename, assembly metadata, and BepInEx plugin version together. Installable build output is build/ScreenStocksStats-vVERSION.dll. The unversioned DLL and other files in build/ are compiler outputs; install only the versioned DLL. Keep only one version in the game’s BepInEx/plugins folder. Remove the old ScreenStocksStats.dll or older version before installing an update.

## Stocks tab (0.1.2)

The Stocks tab widens the panel to show a three-column live grid of demo-available stocks. Each card shows the current quoted price, latest 120 locally loaded history samples, price range and percentage change from first to last valid displayed sample. Charts have independent vertical scales; the horizontal axis is sample order, not a fixed time period. Green/red indicates the change over the displayed samples. Refresh is twice per second. Missing history displays a waiting message. No new network requests are made. Large future catalogs can scroll. Resize still scales text and controls and the window fits within the screen.

0.1.2 validation: Release build succeeded with zero warnings/errors. In-game chart rendering and input behavior still need testing.

## Chart rendering fix (0.1.3)

Replaced rotated GUI line segments with a cached raster texture per chart. Each chart is drawn only within its plot rectangle, using normal GUI clipping and scaling. Textures are released when refreshed or the plugin unloads. Release build passed; confirm in game that moving/scaling the panel and scrolling no longer scatter chart lines.

## Game theme integration (0.1.4)

Panel and buttons follow the equipped BGSkin colors automatically, with beveled borders and contrasting text. Chart cards use a dark tint derived from that palette for readable price lines. Changing the equipped skin rebuilds only plugin-owned UI resources. This adapts colors and frame styling; it does not reproduce the game’s shader effects, bloom, or CRT post-processing. Release compilation passed; visual confirmation in game is pending.

## Chart scale correction (0.1.5)

Mini charts now use each stock’s configured graphMinY/graphMaxY and expand only to include out-of-range samples, following the game’s preferred-bound calculation. They also use the game’s chartVisibleTicks/historyLength window instead of a fixed 120 samples. Axis labels show the actual vertical limits. Percent change still describes first-to-last displayed valid sample. Mini-card aspect ratios differ from the main chart, so pixel slopes will not be identical. Build passed; in-game comparison pending.

## Free window resizing (0.1.6)

Drag any edge to adjust width or height independently, or a corner to adjust both. Title dragging still moves the panel. Size is remembered across tabs and restarts; Stocks no longer forces a wide window. Chart columns adapt to available width, with scrolling when cards do not fit. A- and A+ adjust text/control scale separately. Minimum size is 300 by 240 UI units, bounded by the screen. Release build passed; mouse interactions need in-game verification.

## Readability (0.1.7)

Larger labels, bold numbers and buttons, higher-contrast text based on theme luminance, thicker chart strokes and stronger grid lines. Chart axis and change labels use separate lines; cards have more room. A-/A+ remains available for additional scaling. Release build passed; visual verification in game is pending.

## Label layout fix (0.1.8)

Ticker and price have separate full-width rows. Header heights are measured from the font and padding instead of fixed at 20–22 pixels. Chart cards are taller to retain room for the graph and axis labels. Build passed; check labels in game at your preferred size.

## Settings tab (0.1.9)

Includes theme following/dark theme, text scale, independent width/height, grid visibility, line weight, refresh interval, shortcut reminder and Reset display settings. Changes save automatically to the plugin configuration. Line weight updates on the next chart refresh. Reset does not reset session statistics. Settings remains usable while game data loads. Release build passed; UI checks in game remain pending.

## Settings refinements (0.1.10)

Window dimensions are now screen pixels with 1-pixel steps. Existing sizes migrate to pixel dimensions. Text size changes in 1-percentage-point steps and keeps window pixel dimensions unchanged. Fastest refresh reads the game every rendered frame, without extra server requests; unchanged chart textures are reused. Background transparency supports 0–90%, leaving text and chart strokes opaque. Chart price text accepts a labeled #RRGGBB hex code and previews valid colors; invalid input retains the last valid color. Release build passed; verify settings in game.

## Stats row clipping fix (0.1.11)

Portfolio, timer and holding labels/values now share a measured row with extra vertical padding, top alignment, and wrapping for narrow windows. Settings numbers have a minimum row height. Release build passed; confirm the result at your text size in game.

## Window position (0.1.12)

The panel saves its position after a drag/resize ends and restores it next launch, keeping it inside the current screen. Reset display settings also resets the saved position. Build passed; restart verification pending. No chart labeling/range change is included in this version; awaiting clarification about the reported BASE/PLAIN screenshot.

## Reliable position saving (0.1.13)

Replaced native GUI.Window title dragging with explicit mouse capture in screen coordinates. Title dragging and top/left resizing now mark position changes directly and save on release. Rendering clamps to the screen without replacing saved coordinates during startup resolution changes. After installing, drag the panel to the desired location once, release, and restart to verify persistence. Build passed; runtime restart check pending.

## Position stats on charts (0.1.14)

Current price is at the top-right, retaining your hex color setting. Beneath the ticker, held positions show average entry and unrealized dollar/percentage P/L. Bold green/red text, signed values and up/down markers distinguish gains/losses; opaque dark badges preserve contrast even with transparent windows. Short positions use average short entry and reverse the price-change calculation; their percentage is relative to entry price, not collateral ROI. No position is labeled explicitly. Values exclude closing impact. Card heights increased to accommodate the information. Build passed; visual checks pending.

## Chart footer cleanup (0.1.15)

Removed axis-range and displayed-history percent-change footer labels. The graph fills the freed space. Position gain/loss remains under average entry. Build passed.

## Chart height (0.1.16)

Settings > Charts > Chart height adjusts the graph area from 30 to 400 UI units in steps of 1, default 90. It does not change text size or window dimensions. Card height follows the graph height and retains room for position labels. Preference saves automatically and Reset display settings restores 90. Build passed; in-game layout verification pending.

## Version footer and chart navigation (0.1.17)

Version is always displayed in the panel footer, centered outside the scrolling content, with no setting to hide it. Settings > Charts > Click chart to open stock in-game enables manual selection/navigation (off by default). It respects stock eligibility and tutorial input lock; no trades are placed. This is a navigation feature, so earlier descriptions of strictly read-only game interaction now exclude this explicit selection action. Build passed with zero warnings/errors; in-game click/navigation and footer layout verification pending.

## Visible settings checkboxes (0.1.18)

Settings use large rounded checkbox icons with thick borders, contrasting checked fill and a drawn checkmark. Colors follow the selected theme. Labels are bold, the whole row is clickable, and ON/OFF text makes the state explicit. Icons remain opaque with transparent windows. Build passed; appearance still requires in-game review.

## Compact checkboxes (0.1.19)

Checkbox icons reduced from 30 to 22 UI units with tighter row spacing, retaining the themed outline and checkmark. Release build passed.

## Custom theme (0.1.20)

Primary (window background) and secondary (buttons and chart accents) hex fields appear directly below Follow game theme. Both explicitly use #RRGGBB and are disabled/dimmed while theme following is enabled. Turn following off to edit and use your custom colors. Valid changes save automatically; incomplete or invalid input keeps the last valid color. Custom colors survive toggling game-theme following. Reset display settings restores the defaults. Release build passed; visual testing pending.
