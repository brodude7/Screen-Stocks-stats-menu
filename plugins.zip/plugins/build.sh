#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
export DOTNET_CLI_HOME="/Users/dunn/Documents/Codex/2026-09-26/you/work/dotnet-home"
export DOTNET_CLI_TELEMETRY_OPTOUT=1
SDK="/Users/dunn/Documents/Codex/2026-09-26/you/work/dotnet/dotnet"
if command -v dotnet >/dev/null 2>&1; then SDK="$(command -v dotnet)"; fi
"$SDK" build ScreenStocksStats.csproj -c Release "$@"
